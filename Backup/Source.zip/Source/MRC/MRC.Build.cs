// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class MRC : ModuleRules
{
	public MRC(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "EnhancedInput","OnlineSubsystem","OnlineSubsystemSteam","UMG","Slate","SlateCore" });
	}
}
